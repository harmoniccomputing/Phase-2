import time  # This will define 'time'
import matplotlib.pyplot as plt  # This will define 'plt'
import random

def adjust_seed(seed):
    """
    Adjusts the given seed to ensure it has an even number of digits by padding with a zero if necessary.
    
    Parameters:
    - seed: An integer seed.
    
    Returns:
    - An adjusted seed with an even number of digits.
    """
    seed_str = str(seed)
    # Pad with a zero at the front if the number of digits is odd
    if len(seed_str) % 2 != 0:
        seed_str = '0' + seed_str
    return int(seed_str)

def pseudo_rand_num_gen(seed, k):
    """
    Generates k pseudo random numbers using the middle-square method for a given seed with an even number of digits.
    Re-seeds the generator if the seed becomes too small or zero.
    
    Parameters:
    - seed: An initial seed with an even number of digits.
    - k: The number of random numbers to generate.
    
    Returns:
    - A list of k pseudo random numbers.
    """
    n = len(str(seed))  # Number of digits in the seed
    random_numbers = []
    used_seeds = set()  # Keep track of used seeds to avoid repetition

    for _ in range(k):
        # Square the seed and pad with zeros to maintain length if necessary
        squared_seed = str(seed ** 2).zfill(n*2 if len(str(seed ** 2)) % 2 == 0 else n*2 + 1)
        # Extract the middle n digits
        mid = len(squared_seed) // 2
        new_seed = int(squared_seed[mid - n//2: mid + n//2])

        # Check if the new seed is too small or has been used before, and re-seed if necessary
        if new_seed < 10**(n-1) or new_seed in used_seeds:
            new_seed = random.randint(10**(n-1), 10**n - 1)
        used_seeds.add(new_seed)

        seed = new_seed
        # Normalize and add to the list
        random_numbers.append(seed / (10**n))
        
    return random_numbers

if __name__ == "__main__":
        # Use current system time as the seed, adjusting if necessary
        current_time = int(time.time())
        seed = adjust_seed(current_time)

        # Generate pseudo random numbers
        k=input('Enter key: ')
        k= int(k)
        random_values = pseudo_rand_num_gen(seed, k)

        # Plot a histogram of the generated random values
        plt.hist(random_values, bins=10, edgecolor='k')
        plt.title('Histogram of Pseudo Random Numbers')
        plt.xlabel('Normalized Value')
        plt.ylabel('Frequency')
        plt.show()
