import time  # This will define 'time'
import matplotlib.pyplot as plt  # This will define 'plt'

def adjust_seed(seed):
    """
    Adjusts the given seed to ensure it has an even number of digits by padding with a zero if necessary.
    
    Parameters:
    - seed: An integer seed.
    
    Returns:
    - An adjusted seed with an even number of digits.
    """
    seed_str = str(seed)
    # Pad with a zero at the front if the number of digits is odd
    if len(seed_str) % 2 != 0:
        seed_str = '0' + seed_str
    return int(seed_str)

def pseudo_rand_num_gen(seed, k):
    """
    Generates k pseudo random numbers using the middle-square method for a given seed with an even number of digits.
    
    Parameters:
    - seed: An initial seed with an even number of digits.
    - k: The number of random numbers to generate.
    
    Returns:
    - A list of k pseudo random numbers.
    """
    n = len(str(seed))  # Number of digits in the seed
    random_numbers = []
    
    for _ in range(k):
        # Square the seed and pad with zeros to maintain length if necessary
        squared_seed = str(seed ** 2).zfill(n*2 if len(str(seed ** 2)) % 2 == 0 else n*2 + 1)
        # Extract the middle n digits
        mid = len(squared_seed) // 2
        seed = int(squared_seed[mid - n//2: mid + n//2])
        # Normalize and add to the list
        random_numbers.append(seed / (10**n))
        
    return random_numbers

# Use current system time as the seed, adjusting if necessary
current_time = int(time.time())
seed = adjust_seed(current_time)

# Generate pseudo random numbers
k = 21000  # Number of random numbers to generate
random_values = pseudo_rand_num_gen(seed, k)

# Plot a histogram of the generated random values
plt.hist(random_values, bins=100, edgecolor='k')
plt.title('Histogram of Pseudo Random Numbers')
plt.xlabel('Normalized Value')
plt.ylabel('Frequency')
plt.show()
