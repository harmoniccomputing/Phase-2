from q1_v2_a import pseudo_rand_num_gen 
from q1_v2_a import adjust_seed

