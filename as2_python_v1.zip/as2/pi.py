import time
import random
from q1_v2_a import pseudo_rand_num_gen 
from q1_v2_a import adjust_seed

# Using system time as seed for the pseudo-random number generator
current_time = int(time.time())
seed = adjust_seed(current_time)

# Define a function to estimate pi using Monte Carlo simulation
def estimate_pi(n_points):
    points_inside_circle = 0
    pseudo_random_points = pseudo_rand_num_gen(seed, n_points*2)  # Generate 2n random numbers for x and y

    # Split the generated numbers into x and y coordinates
    x_coords = pseudo_random_points[:n_points]
    y_coords = pseudo_random_points[n_points:]

    for x, y in zip(x_coords, y_coords):
        if x**2 + y**2 <= 1:  # Check if the point is inside the circle
            points_inside_circle += 1

    # Calculate the estimated value of pi
    pi_estimate = 4 * (points_inside_circle / n_points)
    return pi_estimate

# Estimate pi using both the custom pseudo-random generator and the built-in random function for comparison
n = 1000000  # Number of random points to generate

# Estimate pi using pseudo-random number generator
pi_pseudo_rand = estimate_pi(n)

# Estimate pi using python's built-in random function
def estimate_pi_builtin(n_points):
    points_inside_circle = 0
    for _ in range(n_points):
        x, y = random.random(), random.random()
        if x**2 + y**2 <= 1:
            points_inside_circle += 1

    return 4 * (points_inside_circle / n_points)

pi_builtin_rand = estimate_pi_builtin(n)

# Return both estimates
pi_pseudo_rand, pi_builtin_rand

print(pi_pseudo_rand, pi_builtin_rand)