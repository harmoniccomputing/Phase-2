from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token
import MySQLdb.cursors
from werkzeug.utils import secure_filename
from flask_wtf import FlaskForm
from wtforms import FileField, SubmitField
from wtforms.validators import DataRequired
import mysql.connector
from flask import flash  # Import flash if you haven't already
import logging
import re
import os
#logging.basicConfig(filename='app.log', level=logging.INFO)

app = Flask(__name__)
app.secret_key = 'secret_key'
bcrypt = Bcrypt(app)
app.config['JWT_SECRET_KEY'] = '1a2b3c4d5e6d7g8h9i10'  # Change this to your JWT Secret Key
jwt = JWTManager(app)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'computing@123!'
app.config['MYSQL_DB'] = 'loginapp'

mysql = MySQL(app)

@app.route('/pythonlogin/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s', [username])
        account = cursor.fetchone()
        if account and bcrypt.check_password_hash(account['password'], password):
            access_token = create_access_token(identity=username)
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
            session['jwt_token'] = access_token  # Storing JWT token in session
            return redirect(url_for('home'))
        else:
            flash("Incorrect username/password!", "danger")
    return render_template('auth/login.html', title="Login")

@app.route('/pythonlogin/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM accounts WHERE username LIKE %s", [username])
        account = cursor.fetchone()
        if account:
            flash("Account already exists!", "danger")
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            flash("Invalid email address!", "danger")
        elif not re.match(r'[A-Za-z0-9]+', username):
            flash("Username must contain only characters and numbers!", "danger")
        elif not username or not password or not email:
            flash("Please fill out the form!", "danger")
        else:
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
            cursor.execute('INSERT INTO accounts VALUES (NULL, %s, %s, %s)', (username, email, hashed_password))
            mysql.connection.commit()
            flash("You have successfully registered!", "success")
            return redirect(url_for('login'))
    elif request.method == 'POST':
        flash("Please fill out the form!", "danger")
    return render_template('auth/register.html', title="Register")

@app.route('/')
def home():
    if 'loggedin' in session:
        user_id = session['id']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM images WHERE user_id = %s', [user_id])
        images = cursor.fetchall()  # Fetches all user's images
        return render_template('home/home.html', username=session['username'], images=images)
    else:
        return redirect(url_for('login'))

@app.route('/profile')
def profile():
    if 'loggedin' in session:
        # Retrieve user account details from the database using the stored session['id']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE id = %s', [session['id']])
        account = cursor.fetchone()  # This fetches the user's account details as a dictionary

        # Check if account details are found
        if account:
            return render_template('auth/profile.html', account=account, title="Profile")
        else:
            # If no account found with the session ID, clear the session and redirect to login
            session.pop('loggedin', None)
            session.pop('id', None)
            session.pop('username', None)
            flash("Unable to find account details.", "danger")
            return redirect(url_for('login'))
    else:
        return redirect(url_for('login'))


#app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'uploads')
#os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

UPLOAD_FOLDER = 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class UploadForm(FlaskForm):
    file = FileField('Image File', validators=[DataRequired()], render_kw={"multiple": True})
    submit = SubmitField('Save Images')


def store_image_in_db(user_id, file_path, file_name, binary_data):
    try:
        connection = mysql.connector.connect(host='localhost',
                                             database='loginapp',
                                             user='root',
                                             password='computing')
        if connection.is_connected():
            cursor = connection.cursor()
            sql_insert_query = """ INSERT INTO images
                                   (user_id, image, image_name, image_path) 
                                   VALUES (%s, %s, %s, %s)"""
            cursor.execute(sql_insert_query, (user_id, binary_data, file_name, file_path))
            connection.commit()
            print("Image inserted successfully into the images table")
    except mysql.connector.Error as error:
        print(f"Failed to insert data into MySQL table {error}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if 'loggedin' not in session:
        return redirect(url_for('login'))

    form = UploadForm()  # Instantiate your form here

    if request.method == 'POST' and form.validate_on_submit():
        user_id = session['id']
        files = request.files.getlist('file.file')  # Adjusted to work with FlaskForm
        successful_uploads = 0

        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(f"{user_id}_{file.filename}")
                user_folder = os.path.join(app.config['UPLOAD_FOLDER'], str(user_id))
                if not os.path.exists(user_folder):
                    os.makedirs(user_folder)
                file_path = os.path.join(user_folder, filename)
                file.save(file_path)
                
                with open(file_path, 'rb') as img_file:
                    binary_data = img_file.read()

                store_image_in_db(user_id, file_path, filename, binary_data)
                successful_uploads += 1

        if successful_uploads > 0:
            flash(f'Successfully uploaded {successful_uploads} images.', 'success')
            return redirect(url_for('home'))  # Adjust as needed
        else:
            flash('No files were uploaded.', 'danger')

    # Pass the form variable to the template for GET requests or failed POST requests
    return render_template('home/upload.html', form=form)


@app.route('/create', methods=['GET', 'POST'])
def create():
    if 'loggedin' in session:
        if request.method == 'POST':
            # Handle video creation
            pass
        return render_template('create.html')
    else:
        return redirect(url_for('login'))


@app.route('/logout')
def logout():
    # Remove session data, this will log the user out
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('username', None)
    session.pop('jwt_token', None)
    # Redirect to login page
    return redirect(url_for('login'))

if __name__ =='__main__':
    app.run(debug=True)
